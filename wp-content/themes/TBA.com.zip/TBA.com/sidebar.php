
<?php
/**
 * The Template for displaying all single posts
 *
 *
 * @package  WordPress
 * @subpackage  Timber
 */

$data['footer_widgets'] = Timber::get_widgets('footer-widget');
Timber::render( array( 'sidebar.twig' ), $data );

